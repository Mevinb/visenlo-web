"""Shared ONNX execution settings for predictable local CPU/GPU operation."""

from __future__ import annotations

import ctypes
import logging
import os
import sys
from functools import lru_cache

logger = logging.getLogger("visenlo")


def session_options():
    import onnxruntime as ort

    options = ort.SessionOptions()
    # A separate all-core thread pool per detector/parser/swapper/restorer can
    # make the desktop unresponsive and is slower than a small shared budget.
    options.intra_op_num_threads = min(4, os.cpu_count() or 1)
    options.inter_op_num_threads = 1
    return options


@lru_cache(maxsize=1)
def preferred_providers():
    import onnxruntime as ort

    if os.environ.get("VISENLO_DEVICE", "").lower() == "cpu":
        return ["CPUExecutionProvider"]
    if "CUDAExecutionProvider" not in ort.get_available_providers():
        return ["CPUExecutionProvider"]
    # An installed GPU wheel advertises CUDA even without a working driver.
    # Check the driver before loading every large model and emitting errors.
    try:
        driver = ctypes.CDLL("nvcuda.dll" if sys.platform == "win32" else "libcuda.so.1")
        if driver.cuInit(0) != 0:
            return ["CPUExecutionProvider"]
        if hasattr(ort, "preload_dlls"):
            ort.preload_dlls()
    except (OSError, AttributeError):
        return ["CPUExecutionProvider"]
    return [("CUDAExecutionProvider", {
        "cudnn_conv_algo_search": "HEURISTIC",
        "arena_extend_strategy": "kSameAsRequested",
        "cudnn_conv_use_max_workspace": "1",
    }), "CPUExecutionProvider"]


def create_session(path, providers=None):
    import onnxruntime as ort

    requested = providers or preferred_providers()
    try:
        return ort.InferenceSession(str(path), sess_options=session_options(), providers=requested)
    except Exception as exc:
        gpu = any((p[0] if isinstance(p, tuple) else p) == "CUDAExecutionProvider" for p in requested)
        if not gpu or not any(word in str(exc).lower() for word in ("cuda", "cublas", "cudnn", "provider")):
            raise
        logger.warning("CUDA session unavailable; using CPU: %s", exc)
        return ort.InferenceSession(str(path), sess_options=session_options(), providers=["CPUExecutionProvider"])
