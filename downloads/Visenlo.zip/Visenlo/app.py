"""Standalone Gradio launcher for Visenlo Swap Engine v1."""

from __future__ import annotations

import argparse
import logging
import html
import os
import queue
import subprocess
import sys
import threading
import time
from pathlib import Path

os.environ.setdefault("GRADIO_ANALYTICS_ENABLED", "False")

import cv2
import gradio as gr
import numpy as np
from PIL import Image, ImageOps

from visenlo import PipelineConfig, VisenloPipeline
from visenlo.swappers import MODELS as SWAP_MODELS, model_choices, missing_assets, runtime_ready

ROOT = Path(__file__).resolve().parent
MODELS = Path(os.environ.get("VISENLO_MODELS", os.environ.get("REACTORX_MODELS", ROOT / "models")))
_pipeline = None
_pipeline_lock = threading.Lock()
_run_lock = threading.Lock()
_setup_lock = threading.Lock()
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)-7s] %(name)s: %(message)s",
    datefmt="%H:%M:%S",
)
logging.getLogger("visenlo").propagate = False
logger = logging.getLogger("visenlo.app")
APP_CSS = (ROOT / "app.css").read_text()

SWAPPER_CHOICES = model_choices()

# --- Model checker (licensing: no auto-download) ---
MODEL_SPECS = [
    ("buffalo_l",        "models/insightface/models/buffalo_l", ["det_10g.onnx","2d106det.onnx","1k3d68.onnx","genderage.onnx","w600k_r50.onnx"], "Face analysis (detection+landmarks+identity)", "Install explicitly · research-only"),
    ("inswapper_128",    "models/inswapper_128.onnx",           None, "Default swap model 128px", "Research-only"),
    ("BiSeNet",          "models/bisenet_resnet_34.onnx",       None, "Face parsing (~90 MB)", "MIT"),
    ("CodeFormer",       "models/codeformer.onnx",              None, "Restoration (~377 MB, optional)", "CC BY-NC 4.0"),
    ("XSeg",             "models/xseg_1.onnx",                  None, "Occlusion mask (~68 MB, optional)", "GPL-3.0"),
]

def _check_models(selected="inswapper_128.onnx"):
    """Check local assets without initializing models or making network requests."""
    filename = str(selected or "").partition("@")[0]
    if filename not in SWAP_MODELS:
        return '<p class="model-warning">Select a supported face-swap model.</p>', False
    spec = SWAP_MODELS[filename]
    analysis = MODELS / "insightface" / "models" / "buffalo_l"
    analysis_missing = [f for f in MODEL_SPECS[0][2]
                        if not (analysis / f).is_file() or (analysis / f).stat().st_size == 0]
    missing = missing_assets(MODELS, filename)
    # Treat empty/interrupted downloads as missing too.
    for name in [filename] + ([spec.converter + ".onnx"] if spec.converter else []):
        paths = [MODELS / name, MODELS / "insightface" / "models" / name]
        if name not in missing and not any(p.is_file() and p.stat().st_size > 0 for p in paths):
            missing.append(name)
    runtime = runtime_ready(filename)
    can_launch = not analysis_missing and not missing and runtime
    rows = []
    def row(name, ok, note):
        rows.append(f'<div class="model-row"><span><i class="model-dot {"ready" if ok else "missing"}"></i>'
                    f'{html.escape(name)}</span><span>{html.escape(note)}</span></div>')
    row("Face analysis · buffalo_l", not analysis_missing,
        "Installed" if not analysis_missing else f"{5-len(analysis_missing)}/5 files · required")
    row(spec.name, not missing and runtime,
        f"Ready · {spec.size}px native" if not missing and runtime else
        ("Missing: " + ", ".join(missing) if missing else "Additional runtime needed"))
    for name, rel, _, desc, lic in MODEL_SPECS[2:]:
        path = MODELS / rel.removeprefix("models/")
        alt = MODELS / "restoration" / "codeformer.onnx" if name == "CodeFormer" else path
        ok = any(p.is_file() and p.stat().st_size > 0 for p in (path, alt))
        row(name, ok, "Installed · optional" if ok else "Not installed · optional")
    notes = []
    if not can_launch:
        notes.append('<p>Complete the setup below to install the required models on this device. '
                     'Existing files are kept. Nothing downloads until you acknowledge the licenses and click Install.</p>')
        if analysis_missing or "inswapper_128.onnx" in missing:
            notes.append('<p>The core setup installs the buffalo_l analysis pack and InSwapper 128. '
                         'It needs an internet connection once; your photos stay on this device.</p>')
        if missing and filename != "inswapper_128.onnx":
            command = (f"python scripts/setup_{spec.family}.py" if spec.family in ("mobilefaceswap", "facedancer")
                       else f"python scripts/swap_models.py --download --model {filename}")
            notes.append(f'<p>Selected model setup: <code>{html.escape(command)}</code></p>')
        if not runtime:
            notes.append(f'<p>Runtime setup: <code>python scripts/setup_{spec.family}.py</code></p>')
    else:
        notes.append('<p class="model-success">Required assets are installed. You can start a swap.</p>')
    if spec.family == "facedancer":
        notes.append('<p>Experimental backend: real generator inference remains unverified. Official weights require approved access.</p>')
    notes.append('<p class="model-footnote">Optional models improve masking and restoration. Missing optional assets do not block a swap.</p>')
    return '<div class="model-check">' + ''.join(rows + notes) + '</div>', can_launch


def check_models(selected="inswapper_128.onnx"):
    """Refresh readiness without downloads; also used after local setup."""
    markup, can = _check_models(selected)
    if _setup_lock.locked():
        return markup, "Installing models · progress appears in the setup report", gr.update(interactive=False)
    return markup, ("Required models ready" if can else "Selected model needs setup · open Model setup"), gr.update(interactive=can)


def install_models(licenses_accepted, include_optional, selected="inswapper_128.onnx"):
    """Stream one explicitly requested, fixed local installer command."""
    if not licenses_accepted:
        raise gr.Error("Review the model licenses and check the acknowledgement before installing.")
    if not _setup_lock.acquire(blocking=False):
        raise gr.Error("Model installation is already running. Follow its setup report and wait for it to finish.")
    process = None
    reader = None
    stop_reading = threading.Event()
    lines = []
    markup = ""
    started = time.monotonic()
    outcome = "Installation could not start."

    def update(message):
        # Keep browser updates bounded even if a downloader prints noisy errors.
        return (message, markup, "Installing models · keep this app running",
                gr.update(interactive=False), gr.update(interactive=False))

    try:
        markup, _ = _check_models(selected)
        yield update("Preparing local model setup. Existing model files will be kept.")
        command = [sys.executable, "-u", str(ROOT / "scripts" / "download_models.py"), "--download"]
        if include_optional:
            command.append("--all")
        environment = dict(os.environ, VISENLO_MODELS=str(MODELS.resolve()), PYTHONUNBUFFERED="1")
        process = subprocess.Popen(command, cwd=str(ROOT), env=environment,
                                   stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                   text=True, encoding="utf-8", errors="replace", bufsize=1)
        messages = queue.Queue(maxsize=256)

        def enqueue(message):
            while not stop_reading.is_set():
                try:
                    messages.put(message, timeout=.1)
                    return
                except queue.Full:
                    pass

        def read_output():
            try:
                for line in process.stdout:
                    enqueue(line.rstrip()[:1000])
                    if stop_reading.is_set():
                        break
            finally:
                enqueue(None)

        reader = threading.Thread(target=read_output, name="visenlo-model-setup", daemon=True)
        reader.start()
        last_update = 0.0
        finished = False
        while not finished:
            try:
                message = messages.get(timeout=.5)
                if message is None:
                    finished = True
                else:
                    lines.append(message)
                    lines = lines[-120:]
            except queue.Empty:
                pass
            now = time.monotonic()
            if now - started > 7200:
                raise TimeoutError("Installation exceeded two hours. Check your connection and try again; existing models are kept.")
            if finished or now - last_update >= 1:
                elapsed = int(now - started)
                report = ("\n".join(lines) if lines else "Connecting to the model download server…")
                yield update(f"Installing models · {elapsed}s elapsed. Large downloads can take several minutes.\n\n" + report)
                last_update = now
        returncode = process.wait(timeout=10)
        if returncode == 0:
            outcome = "Model installation finished."
        else:
            outcome = ("Installation did not finish. Check the setup report below and your internet connection, "
                       "then click Install to retry. Completed downloads are kept.")
    except (OSError, subprocess.SubprocessError, TimeoutError) as exc:
        logger.warning("Local model installation failed: %s", exc)
        outcome = f"Installation could not finish: {exc}. Existing model files are kept. You can retry."
    finally:
        stop_reading.set()
        if process is not None:
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=5)
            if reader is not None:
                # Normal completion drains the bounded queue before closing.
                reader.join(timeout=1)
            if process.stdout is not None:
                process.stdout.close()
        _setup_lock.release()
    markup, can = _check_models(selected)
    readiness = "Required models ready · you can start a swap" if can else "Selected model still needs setup"
    if not can and process is not None and process.returncode == 0:
        outcome += " Select inswapper_128.onnx to use the core setup, or follow the selected model’s additional setup instructions above."
    yield (outcome + ("\n\n" + "\n".join(lines[-120:]) if lines else ""), markup, readiness,
           gr.update(interactive=can), gr.update(interactive=True))


def get_pipeline(min_face_size, verify_threshold, color_strength, codeformer_enabled,
                 codeformer_weight, sharpen_strength, occluder_enabled,
                 quality_mode="Best likeness", mouth_mode="Swap lips, keep teeth"):
    global _pipeline
    config = PipelineConfig(min_face_size=int(min_face_size),
                            verification_threshold=float(verify_threshold),
                            color_strength=float(color_strength),
                            codeformer_enabled=bool(codeformer_enabled),
                            codeformer_weight=float(codeformer_weight),
                            sharpen_strength=float(sharpen_strength),
                            occluder_enabled=bool(occluder_enabled),
                            quality_mode=("best_likeness" if str(quality_mode).startswith("Best") else "manual"),
                            mouth_mode={
                                "Swap lips, keep teeth": "swap_lips_keep_teeth",
                                "Keep entire target mouth": "keep_target_mouth",
                                "Swap entire mouth": "swap_mouth",
                            }.get(str(mouth_mode), "swap_lips_keep_teeth"))
    with _pipeline_lock:
        if _pipeline is None:
            _pipeline = VisenloPipeline(str(MODELS), config)
        else:
            _pipeline.update_config(config)
    return _pipeline


def _bgr(image):
    return cv2.cvtColor(np.asarray(ImageOps.exif_transpose(image).convert("RGB")), cv2.COLOR_RGB2BGR)


def _upload_path(item):
    """Resolve a gr.File entry to a filesystem path (str, Path, dict, or file object)."""
    if isinstance(item, str):
        return item
    if isinstance(item, dict):
        # Gradio FileData dict (e.g. {"name": "/tmp/...", "orig_name": "photo.jpg"})
        return item.get("name") or item.get("path") or item.get("orig_name") or ""
    # pathlib.Path or file-like with .name
    if isinstance(item, Path):
        return str(item)
    return getattr(item, "name", str(item) if item is not None else "")


def _target_path(item):
    """Normalize a single File or Gallery entry to a filesystem path string.

    Gallery interactive values are (path, caption) tuples where path may itself
    be a FileData dict; File values are plain paths/dicts.
    """
    if isinstance(item, (list, tuple)):
        if len(item) == 0:
            return ""
        # Gallery tuple (media, caption) — caption is str/None
        if len(item) == 2 and (item[1] is None or isinstance(item[1], str)):
            return _upload_path(item[0])
        # Fallback: treat as generic sequence, take first element
        return _upload_path(item[0])
    return _upload_path(item)


def run_swap(targets, ref1, ref2, ref3, ref4, target_index, source_index, match_mode,
             swapper_model, min_face_size, verify_threshold, color_strength,
             codeformer_enabled, codeformer_weight, sharpen_strength,
             occluder_enabled, quality_mode, mouth_mode):
    with _run_lock:
        yield from _run_swap(targets, ref1, ref2, ref3, ref4, target_index, source_index,
                             match_mode, swapper_model, min_face_size, verify_threshold,
                             color_strength, codeformer_enabled, codeformer_weight,
                             sharpen_strength, occluder_enabled, quality_mode, mouth_mode)


def _run_swap(targets, ref1, ref2, ref3, ref4, target_index, source_index, match_mode,
             swapper_model, min_face_size, verify_threshold, color_strength,
             codeformer_enabled, codeformer_weight, sharpen_strength,
             occluder_enabled, quality_mode, mouth_mode):
    """Swap one or many selected targets against the same references.

    Streams results so the gallery and report update after each image; a
    failing image is reported and skipped without stopping the rest. The
    pipeline auto-saves every completed swap as <date>_<NN>.png.
    """
    if not targets:
        raise gr.Error("Select at least one target image.")
    if ref1 is None:
        raise gr.Error("Reference 1 is required.")
    if not _check_models(swapper_model)[1]:
        raise gr.Error("Required model files are missing. Open Model setup and re-check after installing.")
    mode = "index" if match_mode.startswith("Manual") else "gender"
    files = list(targets) if isinstance(targets, (list, tuple)) else [targets]
    logger.info("Swap requested: %d image(s), swapper=%s target_face_idx=%d "
                "source_face_idx=%d match_mode=%s codeformer=%s sharpen=%.2f occluder=%s "
                "quality=%s mouth=%s",
                len(files), swapper_model, target_index, source_index, mode,
                codeformer_enabled, sharpen_strength, occluder_enabled,
                quality_mode, mouth_mode)
    yield [], "Preparing models. The first swap takes longer while the local models load."
    references = [_bgr(image) for image in (ref1, ref2, ref3, ref4) if image is not None]
    pipeline = get_pipeline(min_face_size, verify_threshold, color_strength,
                            codeformer_enabled, codeformer_weight, sharpen_strength,
                            occluder_enabled, quality_mode, mouth_mode)
    gallery, report = [], []
    total = len(files)
    failures = 0
    for i, item in enumerate(files):
        path = _target_path(item)
        name = Path(path).name if path else f"image {i + 1}"
        # With a single image selected the plain name keeps the report clean;
        # batches get numbered lines like "[2/5] photo.jpg: ...".
        prefix = f"[{i + 1}/{total}] " if total > 1 else ""
        yield gallery.copy(), f"Processing image {i+1} of {total}…\n" + "\n".join(report)
        try:
            with Image.open(path) as image:
                image.load()
                result, status = pipeline.process(references, _bgr(image),
                                                  int(source_index), int(target_index),
                                                  swapper_model, match_mode=mode)
            gallery.append(Image.fromarray(cv2.cvtColor(result, cv2.COLOR_BGR2RGB)))
            report.append(f"{prefix}{name}: {status}")
        except Exception as exc:
            failures += 1
            logger.warning("Swap failed for %s (%s)", name, exc, exc_info=True)
            # Avoid leaking absolute temp paths in user-visible report.
            safe_msg = str(exc).replace(path, name) if path else str(exc)
            report.append(f"{prefix}{name}: FAILED - {safe_msg}")
        yield gallery.copy(), "\n".join(report)
    summary = f"Finished: {len(gallery)} of {total} images completed" + (f" · {failures} failed" if failures else "")
    yield gallery.copy(), summary + "\n\n" + "\n".join(report)


def build_ui():
    theme = gr.themes.Base(primary_hue="lime", neutral_hue="zinc",
                           font=["Arial", "sans-serif"], font_mono=["ui-monospace", "monospace"])
    palette = dict(body_background_fill="#10120f", body_text_color="#e9ede5",
                   body_text_color_subdued="#9ba595", background_fill_primary="#191c17",
                   background_fill_secondary="#20251d", block_background_fill="#191c17",
                   block_border_color="#343c2e", border_color_primary="#343c2e",
                   input_background_fill="#11150e", input_border_color="#434d3c",
                   button_primary_background_fill="#b9ec80", button_primary_text_color="#18200f",
                   button_primary_border_color="#b9ec80", button_primary_background_fill_hover="#cef3a7",
                   button_secondary_background_fill="#242a1f", button_secondary_text_color="#e9ede5",
                   button_secondary_border_color="#434d3c", block_label_background_fill="#191c17",
                   block_label_text_color="#d6dfcd", block_title_text_color="#e9ede5")
    theme.set(**{key+suffix: value for key, value in palette.items() for suffix in ("", "_dark")})
    with gr.Blocks(title="Visenlo · local face studio", theme=theme, css=APP_CSS,
                   analytics_enabled=False) as app:
        gr.HTML('<header class="studio-header"><div class="studio-brand"><span class="brand-symbol">v.</span>'
                '<span>visenlo<span class="brand-divider">/</span><small>local face studio</small></span></div>'
                '<span class="local-badge"><i></i> Processing stays on your device</span></header>'
                '<div class="studio-intro"><span class="studio-eyebrow">YOUR IMAGES. YOUR MACHINE.</span>'
                '<h1>A different face.<br><em>The same moment.</em></h1>'
                '<p>Bring a reference. Choose your scene. Create a face swap locally, '
                'with control over the details.</p></div>')
        init_html, init_can = _check_models()
        with gr.Accordion("Model setup · local assets and readiness", open=not init_can):
            model_html = gr.HTML(init_html)
            gr.HTML('<div class="setup-intro"><h2>Set up once. Create locally.</h2>'
                    '<p>Install the required face-analysis and swap models here. '
                    'Downloads come from GitHub and Hugging Face; images are never uploaded. '
                    'Model licenses determine how you can use the results.</p>'
                    '<p><a href="https://github.com/deepinsight/insightface/tree/master/model_zoo" '
                    'target="_blank" rel="noopener noreferrer">Review InsightFace model terms ↗</a> '
                    '<span>·</span> <a href="https://huggingface.co/facefusion/models-3.0.0" '
                    'target="_blank" rel="noopener noreferrer">Swap and finishing model sources ↗</a> '
                    '<span>·</span> <a href="https://github.com/sczhou/CodeFormer/blob/master/LICENSE" '
                    'target="_blank" rel="noopener noreferrer">CodeFormer license ↗</a></p></div>')
            licenses_accepted = gr.Checkbox(value=False, label="I have reviewed the model licenses and agree to their permitted use.",
                                            elem_id="model-license-acknowledgement")
            include_optional = gr.Checkbox(value=False, label="Also install optional face parsing, restoration, and occlusion models",
                info="Adds BiSeNet, CodeFormer, and XSeg. Takes more time and disk space; their upstream licenses also apply.")
            install_btn = gr.Button("Install required models", variant="primary", interactive=False, elem_id="install-models")
            setup_report = gr.Textbox(label="Model setup report", value="No downloads started. Existing models are kept when you install or retry.",
                                      lines=4, max_lines=10, interactive=False, elem_id="model-setup-report")
            with gr.Row():
                recheck_btn = gr.Button("Re-check models", size="sm")
                launch_info = gr.Markdown("Required models ready" if init_can else "Setup needed before your first swap")
        with gr.Row(equal_height=True, elem_classes="workspace"):
            with gr.Column(scale=6, min_width=280):
                gr.HTML('<div class="step-heading"><span>01</span><h2>Choose your scene</h2><small>ONE OR MANY IMAGES</small></div>')
                targets = gr.Gallery(label="Target images", columns=3, rows=1, height=320,
                    object_fit="contain", allow_preview=True, show_download_button=False,
                    show_fullscreen_button=True, file_types=["image"], type="filepath",
                    interactive=True, elem_classes="vs-targets")
                with gr.Row():
                    upload_btn = gr.UploadButton("+ Add more images", file_count="multiple", file_types=["image"], size="sm")
                    clear_btn = gr.Button("Clear targets", size="sm")
                gr.Markdown("The scene, pose, and unselected faces stay with the target. Click a thumbnail to inspect it.", elem_classes="quiet-note")
            with gr.Column(scale=4, min_width=280):
                gr.HTML('<div class="step-heading"><span>02</span><h2>Add a reference</h2></div>')
                ref1 = gr.Image(type="pil", label="Reference face · required", height=320, sources=["upload"], elem_id="primary-reference")
                gr.Markdown("Use a sharp, well-lit face. Add more photos of the same person to help with identity matching.", elem_classes="quiet-note")
                with gr.Accordion("Additional references · optional", open=False):
                    with gr.Row():
                        ref2 = gr.Image(type="pil", label="Reference 2", height=170, sources=["upload"])
                        ref3 = gr.Image(type="pil", label="Reference 3", height=170, sources=["upload"])
                        ref4 = gr.Image(type="pil", label="Reference 4", height=170, sources=["upload"])
        gr.HTML('<div class="step-heading settings-heading"><span>03</span><h2>Make it yours</h2></div>')
        with gr.Row():
            quality_mode = gr.Radio(["Best likeness", "Manual"], value="Best likeness", label="Quality mode",
                info="Best likeness compares several resolutions. Manual runs your selected model once.")
            swapper_model = gr.Dropdown(choices=SWAPPER_CHOICES, value="inswapper_128.onnx", label="Face swap model",
                info="@256 / @512 set the aligned face resolution, not the image dimensions.", filterable=True)
        with gr.Accordion("Fine-tune · face selection, blending, and restoration", open=False):
            with gr.Row():
                match_mode = gr.Radio(["Manual (target index)", "Gender match (auto)"], value="Manual (target index)",
                    label="Face matching", info="Faces are numbered from 0, left to right. Auto uses the model’s estimated reference gender.")
                target_index = gr.Slider(0, 10, value=0, step=1, label="Target face index")
                source_index = gr.Slider(0, 10, value=0, step=1, label="Reference face index")
            with gr.Row():
                min_face_size = gr.Slider(24, 256, value=48, step=4, label="Minimum face size")
                verify_threshold = gr.Slider(0, 1, value=.30, step=.01, label="Identity threshold",
                    info="Flags low similarity in the report; results are still shown for review.")
                color_strength = gr.Slider(0, 1, value=.25, step=.05, label="Color matching")
            with gr.Row():
                codeformer_enabled = gr.Checkbox(value=True, label="Guarded CodeFormer restoration",
                    info="Optional. Accepted only when reference similarity is preserved.")
                codeformer_weight = gr.Slider(0, 1, value=.9, step=.05, label="Restoration fidelity")
                sharpen_strength = gr.Slider(0, 1, value=.5, step=.05, label="Sharpening")
            occluder_enabled = gr.Checkbox(value=True, label="Preserve objects in front of the face · XSeg",
                info="Optional masking model. Falls back to standard masking when unavailable.")
            mouth_mode = gr.Radio(["Swap lips, keep teeth", "Keep entire target mouth", "Swap entire mouth"],
                value="Swap lips, keep teeth", label="Mouth handling")
        swap = gr.Button("Run identity swap →", variant="primary", interactive=init_can, elem_id="run-swap")
        gr.Markdown("First run loads the models. Best likeness takes longer; results appear as each image finishes.", elem_classes="quiet-note")
        gr.HTML('<div class="step-heading results-heading"><span>04</span><h2>Your results</h2><small>FULL-RESOLUTION PNG</small></div>')
        output = gr.Gallery(label="Swapped images", format="png", columns=3, height=350, object_fit="contain",
            allow_preview=True, show_fullscreen_button=True, show_download_button=True,
            interactive=False, elem_classes="vs-gallery")
        status = gr.Textbox(label="Processing report", value=("Your workspace is ready. Add a target image and a reference to begin." if init_can else
                             "Open Model setup above and install the required models before your first swap."),
                            lines=3, interactive=False, elem_classes="vs-status")
        gr.HTML('<footer class="studio-footer"><span>visenlo <b>·</b> made to run locally</span>'
                '<span>Results save to outputs/ · Use images you own or have permission to edit.</span></footer>')

        def _append_uploads(new_files, current_gallery):
            if not new_files:
                return current_gallery or []
            if not isinstance(new_files, (list, tuple)):
                new_files = [new_files]
            current = list(current_gallery or [])
            seen = {_target_path(item) for item in current}
            for item in new_files:
                path = _target_path(item)
                if path and path not in seen:
                    current.append((path, None))
                    seen.add(path)
            return current

        recheck_btn.click(check_models, [swapper_model], [model_html, launch_info, swap], api_name="check_models")
        swapper_model.change(check_models, [swapper_model], [model_html, launch_info, swap], api_name=False)
        licenses_accepted.change(lambda accepted: gr.update(interactive=bool(accepted) and not _setup_lock.locked()),
                                 licenses_accepted, install_btn, api_name=False)
        setup_event = install_btn.click(install_models, [licenses_accepted, include_optional, swapper_model],
                          [setup_report, model_html, launch_info, swap, install_btn],
                          concurrency_limit=1, concurrency_id="model_setup", api_name="install_models")
        # Re-read current controls if the user changed them while downloading.
        setup_complete = setup_event.then(check_models, [swapper_model],
                                           [model_html, launch_info, swap], api_name=False)
        setup_complete.then(lambda accepted: gr.update(interactive=bool(accepted) and not _setup_lock.locked()),
                            licenses_accepted, install_btn, api_name=False)
        match_mode.change(lambda mode: gr.update(visible=mode.startswith("Manual")), match_mode, target_index)
        upload_btn.upload(_append_uploads, [upload_btn, targets], [targets])
        clear_btn.click(lambda: [], outputs=[targets])
        swap.click(run_swap,
            [targets, ref1, ref2, ref3, ref4, target_index, source_index, match_mode, swapper_model,
             min_face_size, verify_threshold, color_strength, codeformer_enabled, codeformer_weight,
             sharpen_strength, occluder_enabled, quality_mode, mouth_mode], [output, status],
            concurrency_limit=1, api_name="run_swap")
    return app


def main():
    parser = argparse.ArgumentParser(description="Visenlo standalone local app")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=7860)
    parser.add_argument("--share", action="store_true")
    parser.add_argument("--no-browser", action="store_true", help="Print the local address without opening a browser")
    args = parser.parse_args()
    logger.info("Visenlo Swap Engine v1")
    logger.info("  models dir:  %s", MODELS)
    logger.info("  server:      %s:%d", args.host, args.port)
    logger.info("  share mode:  %s", args.share)
    build_ui().launch(server_name=args.host, server_port=args.port, share=args.share, inbrowser=not args.no_browser)


if __name__ == "__main__":
    main()
