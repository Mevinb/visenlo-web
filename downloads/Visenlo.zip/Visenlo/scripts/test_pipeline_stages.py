import sys
from pathlib import Path
ROOT = Path("/home/mevlec/Data/ReactorX")
sys.path.insert(0, str(ROOT))

import cv2
import numpy as np

from visenlo import PipelineConfig, VisenloPipeline
from visenlo.engine import build_face_mask, composite_region_mask, color_match, recover_occlusions, sharpen_face_region
from visenlo.pipeline import parse_face, virtual_face, weighted_identity, select_target_record

ref_path = Path("/home/mevlec/Data/test_images/refrence imh/IMG_20251202_235406.jpg")
tgt_path = Path("/home/mevlec/Data/test_images/images _needed_to_be_swapped/00000-2858828682.png")

ref_img = cv2.imread(str(ref_path))
tgt_img = cv2.imread(str(tgt_path))

config = PipelineConfig(save_swaps=False, quality_mode="manual")
p = VisenloPipeline(str(ROOT / "models"), config)

# Initialize by running process
_, _ = p.process([ref_img], tgt_img, swapper_name="inswapper_128.onnx")

swapper = p._swapper
ref_faces = p._detect_adaptive(ref_img)
ref_record = ref_faces[0]
parse_face(ref_img, ref_record, p._parser)
identity = weighted_identity([ref_record])

tgt_faces = p._detect_adaptive(tgt_img)
target_record = select_target_record(tgt_faces, "first", 0, None)
parse_face(tgt_img, target_record, p._parser)
source = virtual_face(identity, ref_record.face)

# 1. Raw swap
swapped = p._run_swap(swapper, tgt_img.copy(), target_record, source, 1, paste_back=True)
raw_sim = p._reference_similarity(swapped, target_record, identity)
raw_diff = np.abs(swapped.astype(float) - tgt_img.astype(float)).mean()
print(f"1. Raw swapped: similarity to ref = {raw_sim:.3f}, diff from target = {raw_diff:.3f}")

cv2.imwrite("/tmp/raw_swapped.png", swapped)

shape = tgt_img.shape
face_mask = build_face_mask(target_record.bbox, shape, landmarks=target_record.landmarks)
interior = composite_region_mask(target_record, shape, ("skin", "eyebrows", "nose", "lips", "neck"))
if interior is None:
    erode_k = max(3, int(max(int(target_record.bbox[2] - target_record.bbox[0]), 1) * .08)) | 1
    interior = cv2.erode(face_mask, np.ones((erode_k, erode_k), np.uint8))

# 2. Color match
res = color_match(swapped, tgt_img, interior, 0.25)
res = np.clip(res, 0, 255).astype(np.uint8)
sim2 = p._reference_similarity(res, target_record, identity)
diff2 = np.abs(res.astype(float) - tgt_img.astype(float)).mean()
print(f"2. After color_match: similarity to ref = {sim2:.3f}, diff from target = {diff2:.3f}")

# 3. Occlusion mask (xseg)
if p._occluder is not None:
    occ_full = p._occluder.map_to_frame(target_record, tgt_img)
    if occ_full is not None:
        print(f"   occ_full min={occ_full.min():.3f}, max={occ_full.max():.3f}, mean={occ_full.mean():.4f}")
        res = (res.astype(np.float32) * (1 - occ_full[:, :, None]) + tgt_img.astype(np.float32) * occ_full[:, :, None]).astype(np.uint8)
        sim3 = p._reference_similarity(res, target_record, identity)
        diff3 = np.abs(res.astype(float) - tgt_img.astype(float)).mean()
        print(f"3. After xseg occluder: similarity to ref = {sim3:.3f}, diff from target = {diff3:.3f}")

# 4. Recover occlusions
res = recover_occlusions(tgt_img, res, face_mask)
sim4 = p._reference_similarity(res, target_record, identity)
diff4 = np.abs(res.astype(float) - tgt_img.astype(float)).mean()
print(f"4. After recover_occlusions: similarity to ref = {sim4:.3f}, diff from target = {diff4:.3f}")

# 5. Mouth preserve
mouth = composite_region_mask(target_record, shape, ("lips", "teeth"), dilate_frac=.006, feather_frac=.012)
if mouth is not None:
    print(f"   mouth min={mouth.min():.3f}, max={mouth.max():.3f}, mean={mouth.mean():.4f}")
    keep = np.clip(mouth, 0, 1)[:, :, None]
    res = (res.astype(np.float32) * (1 - keep) + tgt_img.astype(np.float32) * keep).astype(np.uint8)
    sim5 = p._reference_similarity(res, target_record, identity)
    diff5 = np.abs(res.astype(float) - tgt_img.astype(float)).mean()
    print(f"5. After mouth preserve: similarity to ref = {sim5:.3f}, diff from target = {diff5:.3f}")
