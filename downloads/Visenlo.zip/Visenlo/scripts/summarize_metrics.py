import json
from pathlib import Path

metrics_file = Path("/home/mevlec/Data/test_images/swapped_results/evaluation_metrics.json")
data = json.loads(metrics_file.read_text())

models = [k for k in data.keys() if not k.startswith("_")]

print(f"Reference file used: {data.get('_reference_file')}")
print(f"Total models evaluated: {len(models)}")
print("=" * 80)
print(f"{'Model':<32} | {'Avg ArcFace Sim':<16} | {'Valid Swaps (sim>=0.35)':<24} | {'Failed/No-op'}")
print("-" * 80)

for m in sorted(models):
    targets = data[m]
    sims = []
    for t_name, t_info in targets.items():
        sim_str = t_info.get("similarity", "N/A")
        try:
            val = float(sim_str)
            sims.append(val)
        except ValueError:
            pass
    if sims:
        avg_sim = sum(sims) / len(sims)
        swapped_count = sum(1 for s in sims if s >= 0.35)
        low_count = sum(1 for s in sims if s < 0.35)
        pct = (swapped_count / len(sims)) * 100
        print(f"{m:<32} | {avg_sim:16.3f} | {swapped_count:2d}/{len(sims)} ({pct:5.1f}%)          | {low_count:2d}")
    else:
        print(f"{m:<32} | {'NO DATA':<16} |")
