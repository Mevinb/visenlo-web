import cv2
import numpy as np
from pathlib import Path
from insightface.app import FaceAnalysis

res_dir = Path("/home/mevlec/Data/test_images/swapped_results")
ref_path = Path("/home/mevlec/Data/test_images/refrence imh/IMG_20251202_235406.jpg")
tgt_path = Path("/home/mevlec/Data/test_images/images _needed_to_be_swapped/00000-2858828682.png")

app = FaceAnalysis(name="buffalo_l", root="/home/mevlec/Data/ReactorX/models/insightface", providers=["CUDAExecutionProvider", "CPUExecutionProvider"])
app.prepare(ctx_id=0, det_size=(640, 640))

ref_img = cv2.imread(str(ref_path))
ref_faces = app.get(ref_img)
ref_feat = ref_faces[0].embedding / np.linalg.norm(ref_faces[0].embedding)

tgt_img = cv2.imread(str(tgt_path))
tgt_faces = app.get(tgt_img)
tgt_face = sorted(tgt_faces, key=lambda f: (f.bbox[2]-f.bbox[0])*(f.bbox[3]-f.bbox[1]), reverse=True)[0]
tgt_feat = tgt_face.embedding / np.linalg.norm(tgt_face.embedding)
bx = [int(x) for x in tgt_face.bbox]

h, w, _ = tgt_img.shape
y1, y2 = max(0, bx[1]-20), min(h, bx[3]+20)
x1, x2 = max(0, bx[0]-20), min(w, bx[2]+20)
tgt_crop = tgt_img[y1:y2, x1:x2]

models = sorted([p.name for p in res_dir.iterdir() if p.is_dir()])
print(f"Target: {tgt_path.name}, Face bbox: {bx}, crop size: {tgt_crop.shape}")
print(f"Target vs Reference baseline similarity: {float(np.dot(tgt_feat, ref_feat)):.3f}")
print("=" * 80)
print(f"{'Model':<30} | {'Face MAE':<8} | {'Sim to Ref':<10} | {'Sim to Tgt':<10}")
print("-" * 80)

for m in models:
    out_p = res_dir / m / tgt_path.name
    if not out_p.exists():
        continue
    swapped = cv2.imread(str(out_p))
    swapped_crop = swapped[y1:y2, x1:x2]
    mae = np.abs(swapped_crop.astype(float) - tgt_crop.astype(float)).mean()
    
    sw_faces = app.get(swapped)
    sim_ref = -1.0
    sim_tgt = -1.0
    if sw_faces:
        tc = ((bx[0]+bx[2])/2, (bx[1]+bx[3])/2)
        closest = min(sw_faces, key=lambda f: ((f.bbox[0]+f.bbox[2])/2 - tc[0])**2 + ((f.bbox[1]+f.bbox[3])/2 - tc[1])**2)
        feat = closest.embedding / np.linalg.norm(closest.embedding)
        sim_ref = float(np.dot(feat, ref_feat))
        sim_tgt = float(np.dot(feat, tgt_feat))
    
    print(f"{m:<30} | {mae:8.2f} | {sim_ref:10.3f} | {sim_tgt:10.3f}")
