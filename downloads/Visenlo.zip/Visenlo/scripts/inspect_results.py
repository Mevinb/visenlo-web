import cv2
import numpy as np
from pathlib import Path

res_dir = Path("/home/mevlec/Data/test_images/swapped_results")
targets_dir = Path("/home/mevlec/Data/test_images/images _needed_to_be_swapped")

targets = sorted(list(targets_dir.glob("*.png")) + list(targets_dir.glob("*.jpg")))
sample_targets = targets[:4]

models = [p.name for p in sorted(res_dir.iterdir()) if p.is_dir()]

print(f"{'Model':<30} | " + " | ".join([f"{t.name[:8]} diff(%)" for t in sample_targets]))
print("-" * 85)

for m in models:
    diffs = []
    for t in sample_targets:
        out_p = res_dir / m / t.name
        if not out_p.exists():
            diffs.append("MISSING     ")
            continue
        orig = cv2.imread(str(t))
        swapped = cv2.imread(str(out_p))
        if orig is None or swapped is None:
            diffs.append("ERR         ")
            continue
        diff = np.abs(orig.astype(np.float32) - swapped.astype(np.float32)).mean()
        pct_changed = (np.abs(orig.astype(np.float32) - swapped.astype(np.float32)) > 5).mean() * 100
        diffs.append(f"{diff:5.2f} ({pct_changed:4.1f}%)")
    print(f"{m:<30} | " + " | ".join(diffs))
