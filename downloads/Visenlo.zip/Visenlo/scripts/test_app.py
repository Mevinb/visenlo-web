"""App boundary regressions. No model inference or network access required."""
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import app
from PIL import Image


class AppBoundaryTests(unittest.TestCase):
    def test_readiness_requires_analysis_but_not_optional_finishers(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(app, 'MODELS', Path(directory)):
            root = Path(directory)
            (root / 'inswapper_128.onnx').write_bytes(b'present')
            self.assertFalse(app._check_models()[1])
            analysis = root / 'insightface/models/buffalo_l'
            analysis.mkdir(parents=True)
            for name in app.MODEL_SPECS[0][2]:
                (analysis / name).write_bytes(b'present')
            self.assertTrue(app._check_models()[1])
            (root / 'inswapper_128.onnx').write_bytes(b'')
            self.assertFalse(app._check_models()[1])

    def test_invalid_selection_does_not_crash_checker(self):
        self.assertFalse(app._check_models('not-a-model')[1])
        self.assertFalse(app._check_models(None)[1])

    def test_phone_photo_orientation_applies_before_detection(self):
        image = Image.new('RGB', (30, 10), 'red')
        image.getexif()[274] = 6  # Rotate 90 degrees clockwise.
        self.assertEqual(app._bgr(image).shape, (30, 10, 3))

    def test_upload_normalization_keeps_filedata_path_and_gallery_caption_separate(self):
        self.assertEqual(app._target_path(({'path': '/tmp/image.png'}, 'caption')), '/tmp/image.png')
        self.assertEqual(app._target_path([]), '')
        self.assertEqual(app._upload_path(Path('/tmp/image.png')), '/tmp/image.png')

    def test_batch_reports_failed_input_and_keeps_later_success(self):
        class Pipeline:
            def process(self, references, target, *args, **kwargs):
                return target.copy(), 'Visenlo complete'
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            good = root / 'valid.png'
            bad = root / 'broken.png'
            Image.new('RGB', (32, 32), 'red').save(good)
            bad.write_text('not an image')
            with patch.object(app, '_check_models', return_value=('', True)), patch.object(app, 'get_pipeline', return_value=Pipeline()):
                updates = list(app.run_swap([str(bad), str(good)], Image.open(good), None, None, None,
                    0, 0, 'Manual (target index)', 'inswapper_128.onnx', 48, .3, .25,
                    False, .9, .5, False, 'Manual', 'Swap lips, keep teeth'))
            self.assertEqual(updates[0][0], [])
            gallery, report = updates[-1]
            self.assertEqual(len(gallery), 1)
            self.assertIn('1 of 2 images completed · 1 failed', report)
            self.assertIn('broken.png: FAILED', report)
            self.assertIn('valid.png: Visenlo complete', report)
            self.assertNotIn(str(root), report)

    def test_result_gallery_download_is_a_lossless_png(self):
        import numpy as np
        with patch.object(app, '_check_models', return_value=('', True)):
            ui = app.build_ui()
        gallery = next(component for component in ui.blocks.values()
                       if isinstance(component, app.gr.Gallery) and component.label == 'Swapped images')
        pixels = np.random.default_rng(7).integers(0, 256, (16, 16, 3), dtype=np.uint8)
        data = gallery.postprocess([Image.fromarray(pixels)])
        with Image.open(data.root[0].image.path) as downloaded:
            self.assertEqual(downloaded.format, 'PNG')
            self.assertTrue(np.array_equal(np.asarray(downloaded), pixels))

    def test_missing_input_is_actionable(self):
        with self.assertRaisesRegex(Exception, 'Select at least one target image'):
            list(app.run_swap([], None, None, None, None, 0, 0, 'Manual (target index)',
                'inswapper_128.onnx', 48, .3, .25, False, .9, .5, False, 'Manual', 'Swap lips, keep teeth'))


if __name__ == '__main__':
    unittest.main()
