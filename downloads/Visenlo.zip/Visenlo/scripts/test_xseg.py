import cv2
import numpy as np
from pathlib import Path
import sys
ROOT = Path("/home/mevlec/Data/ReactorX")
sys.path.insert(0, str(ROOT))
from visenlo import PipelineConfig, VisenloPipeline
from visenlo.pipeline import select_target_record

ROOT = Path("/home/mevlec/Data/ReactorX")
ref_path = Path("/home/mevlec/Data/test_images/refrence imh/IMG_20251202_235406.jpg")
tgt_path = Path("/home/mevlec/Data/test_images/images _needed_to_be_swapped/00000-2858828682.png")

ref_img = cv2.imread(str(ref_path))
tgt_img = cv2.imread(str(tgt_path))

config = PipelineConfig()
p = VisenloPipeline(str(ROOT / "models"), config)
# trigger loading
_, _ = p.process([ref_img], tgt_img, swapper_name="inswapper_128.onnx")

tgt_faces = p._detect_adaptive(tgt_img)
target_record = select_target_record(tgt_faces, "first", 0, None)

from visenlo.parsing import aligned_crop_matrix
matrix = aligned_crop_matrix(target_record.face.kps, p._occluder.size)
crop = cv2.warpAffine(tgt_img, matrix, (p._occluder.size, p._occluder.size), flags=cv2.INTER_LINEAR, borderValue=0)

img = cv2.resize(crop, (p._occluder.size, p._occluder.size), interpolation=cv2.INTER_LINEAR)
blob = (img[:, :, ::-1].astype(np.float32) / 255.0)[None]
out = p._occluder.session.run([p._occluder.output_name], {p._occluder.input_name: blob})[0]

print("out shape:", out.shape, "min:", out.min(), "max:", out.max(), "mean:", out.mean())
cv2.imwrite("/tmp/xseg_raw_out.png", (np.clip(out[0], 0, 1) * 255).astype(np.uint8))
cv2.imwrite("/tmp/xseg_crop.png", crop)

occ = p._occluder.detect(crop)
print("occ (detect) min:", occ.min(), "max:", occ.max(), "mean:", occ.mean())

full = p._occluder.map_to_frame(target_record, tgt_img)
print("full (map_to_frame) min:", full.min(), "max:", full.max(), "mean:", full.mean())

# Now check where the face is in full
bx = [int(x) for x in target_record.bbox]
face_occ = full[bx[1]:bx[3], bx[0]:bx[2]]
print("face region in full: min:", face_occ.min(), "max:", face_occ.max(), "mean:", face_occ.mean())
