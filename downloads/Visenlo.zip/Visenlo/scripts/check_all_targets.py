import cv2
import numpy as np
from pathlib import Path
from insightface.app import FaceAnalysis

res_dir = Path("/home/mevlec/Data/test_images/swapped_results")
ref_path = Path("/home/mevlec/Data/test_images/refrence imh/IMG_20251202_235406.jpg")
targets_dir = Path("/home/mevlec/Data/test_images/images _needed_to_be_swapped")
targets = sorted(list(targets_dir.glob("*.png")) + list(targets_dir.glob("*.jpg")))

app = FaceAnalysis(name="buffalo_l", root="/home/mevlec/Data/ReactorX/models/insightface", providers=["CPUExecutionProvider"])
app.prepare(ctx_id=-1, det_size=(640, 640))

ref_img = cv2.imread(str(ref_path))
ref_faces = app.get(ref_img)
ref_feat = ref_faces[0].embedding / np.linalg.norm(ref_faces[0].embedding)

print(f"Total targets: {len(targets)}")
print(f"{'Target':<25} | {'Base':<6} | {'inswapper_128':<14} | {'ghost_1_256':<14} | {'alphaface_256':<14} | {'FaceDancer_A':<14}")
print("-" * 105)

for t in targets[:25]:
    t_img = cv2.imread(str(t))
    t_faces = app.get(t_img)
    if not t_faces:
        print(f"{t.name:<25} | NO FACE DETECTED IN TARGET")
        continue
    t_feat = t_faces[0].embedding / np.linalg.norm(t_faces[0].embedding)
    base_sim = float(np.dot(t_feat, ref_feat))
    
    sims = []
    for m in ["inswapper_128", "ghost_1_256", "alphaface_256", "FaceDancer_config_A"]:
        out_p = res_dir / m / t.name
        if not out_p.exists():
            sims.append("MISSING")
            continue
        sw = cv2.imread(str(out_p))
        sw_faces = app.get(sw)
        if not sw_faces:
            sims.append("NO_FACE")
            continue
        feat = sw_faces[0].embedding / np.linalg.norm(sw_faces[0].embedding)
        s = float(np.dot(feat, ref_feat))
        sims.append(f"{s:.3f}")
    print(f"{t.name:<25} | {base_sim:6.3f} | {sims[0]:<14} | {sims[1]:<14} | {sims[2]:<14} | {sims[3]:<14}")
