# Visenlo · local face studio

Visenlo is an independent **local-first** face-swap application. It does not
require Stable Diffusion WebUI or Forge. `Reactorv4` was used as reference
only and is not imported or modified.

> **Renamed:** this project was previously called **ReactorX**. Everything is
> now **Visenlo** — folder `Visenlo/`, package `visenlo/`, env
> `VISENLO_MODELS` / `VISENLO_REPO` / `VISENLO_ZIP`, class `VisenloPipeline`,
> Docker service `visenlo`, dist `Visenlo-v1.zip`. Old `REACTORX_*` env vars
> and `ReactorXPipeline` still work as aliases so existing setups don't break.

Pipeline: detect → dense landmarks → align → parse → process references →
aggregate identity → swap (**with Pixel Boost**) → CodeFormer restoration
(optional) → color match → occlusion recovery → boundary blend → identity
verification → auto-save.


## Current studio workflow

The studio now has four sections: **Choose your scene**, **Add a reference**,
**Make it yours**, and **Your results**. Add one or many target images, then a
clear reference of the person whose identity to transfer. Additional references
are optional. Quality mode and model selection stay visible; face indices, mouth
handling, blending and restoration are under **Fine-tune**. Results stream into
the full-resolution gallery with a per-image report and batch completion summary.

**First-run setup happens inside the local app.** Open **Model setup**, review the
linked model terms, tick the acknowledgement and click **Install required models**.
The setup report streams progress, keeps existing weights, and refreshes readiness
when finished. Optional finishing models are a separate checkbox. No download
starts from opening the app or checking readiness. You can retry failed transfers.

Advanced terminal setup remains available after reviewing model licenses:

```bash
.venv/bin/python scripts/download_models.py --download
# Add optional finishing models:
.venv/bin/python scripts/download_models.py --download --all
```

Windows uses `.venv\Scripts\python.exe`. Private images, local environments and
weights are excluded from source ZIPs.

## Quick start — automatic local install

All processing stays **100% on your device**. No data leaves your machine.

| OS | Command |
|---|---|
| **Linux / macOS** | `./run.sh` |
| **Windows (PowerShell)** | `.\run.bat` |
| **Windows (CMD)** | double-click `run.bat` |
| **Docker (optional)** | `docker compose up --build` → http://localhost:7860 |

**Option A — Git clone (recommended):**
```bash
git clone https://github.com/Mevinb/Visenlo.git
cd Visenlo
./run.sh                        # Linux/macOS: sets up and launches the app
```

On Windows, use `.\run.bat` after cloning instead of `./run.sh`.

**Option B — ZIP download (no git needed):**
- Download ZIP from GitHub: `Code → Download ZIP` or your website's Download button
- Extract → open the `Visenlo/` folder containing the run scripts → double-click `run.bat` (Windows) or run `./run.sh` (Linux/macOS)
- For you (maintainer) to create the ZIP: `python scripts/make_dist.py` → `dist/Visenlo-v1.zip` (source only; excludes environments, models, private inputs, and outputs; models require explicit setup)

**Advanced maintainer option — hosted bootstrap scripts:**

The promotional site serves the source ZIP. It does not expose a hosted shell
installer. The following placeholders are examples only for maintainers who
choose to separately host the bootstrap scripts; use the ZIP/run-script flow above.
```bash
# Linux / macOS — auto-clones repo if missing:
curl -fsSL https://YOUR_WEBSITE/install.sh | bash
# Windows PowerShell — auto-clones repo if missing:
irm https://YOUR_WEBSITE/install.ps1 | iex
# Set custom repo with: VISENLO_REPO=https://github.com/Mevinb/Visenlo.git
# Legacy REACTORX_REPO / REACTORX_ZIP are still honored as fallback.
```
> `install.sh` / `install.ps1` detect `app.py` missing → `git clone` the repo (or ZIP via `curl`/`Invoke-WebRequest` if git unavailable) → then do the same local setup as Option A.

`run.sh` and `run.bat` call the Python bootstrap internally; users can start
the app directly with the appropriate run script. If a ZIP extractor removes
Unix execute permissions, run `chmod +x run.sh` once before `./run.sh`.

The local studio opens in your browser automatically. If it does not, use the
URL printed in the terminal (normally `http://127.0.0.1:7860`). Pass `--no-browser`
to suppress browser opening. The first launch creates `.venv` and installs the
Python packages locally. Later launches reuse working dependencies without reinstalling them. Use `--host 0.0.0.0` to expose it on your LAN.
`--port 7861` overrides the port; if busy the launcher picks the next free port.

### What the installer does (all locally)
1. **Fetches project files** when using the hosted bootstrap installer (git clone or ZIP)
2. Checks Python 3.10+ exists (guides install if missing)
3. Creates isolated `.venv`, installs `requirements.txt` (working installs reused, CPU/GPU auto-detected)
4. **Model checker** — runs `scripts/download_models.py --check` (no auto-download, licensing) → if missing, shows **Model Setup Guide**
5. Opens the local studio on loopback. Extended diagnostics run only with `./run.sh --self-check`; normal startup does not run the full model test suite.

### First launch flow (licensing-safe)
```
First launch
    ↓
Model checker (scripts/download_models.py --check)
    ↓
Missing model?
    ↓
Open Model setup → review model terms → acknowledge → Install required models
    ↓
Download progress → automatic readiness refresh
    ↓
[✓] buffalo_l   [✓] selected swap model   [optional] BiSeNet / XSeg / CodeFormer
                          ↓
                [Run identity swap]
```

### How distribution works
You host only a light download page/redirect. The user gets the **full** `Visenlo/` folder (app.py, visenlo/, requirements.txt, scripts/, models/ placeholder, outputs/) via one of the three options above. Everything after that runs 100% on their device — no code or images ever go to your server. The app's top **Model setup** accordion shows live checkmarks and disables *Run identity swap* until required models are present.

## Swapping and saved outputs

- **One input, one or many targets.** Select a single target image — or any
  number of them at once — set the references/controls once, and press
  *Run identity swap*. Every selected image is swapped against the same
  references; results stream into the gallery as they finish and the report
  lists status per image. A failing image is reported and skipped without
  stopping the rest.
- **Auto-save.** Every completed swap is written to `outputs/` as
  `<date>_<NN>.png` — for example `outputs/2026-08-26_00.png`,
  `2026-08-26_01.png`, ... The counter keeps incrementing for the day, skips
  names already on disk (atomic `O_EXCL` reservation, safe for concurrent runs),
  and restarts at 00 on a new date. The filename is
  shown in the pipeline report; disable with `PipelineConfig.save_swaps=False`.

### Viewing swapped images

The **Swapped images** gallery shows thumbnails with `object-fit: contain` so the
full image is visible (no cropping). Interaction:

- **Click any thumbnail** to open the full-size preview (lightbox). The preview
  uses `contain` and is constrained to `92vw × 86vh` so tall/wide images fit
  without clipping.
- The preview header has **download**, **fullscreen**, and **close** buttons.
  Left/right halves of the preview image navigate to previous/next; `Esc` /
  arrow keys also work.
- The grid itself has **fullscreen** and **download** toggles and grows with
  content (`height="auto"`, no 420px cap). A dark `1a1a1a` letterbox keeps
  thumbnails readable.

## Pixel Boost — explicit guide (read this)

**Pixel Boost is how Visenlo gets sharp swaps out of the 128px
`inswapper_128` model without changing identity.** The same identity embedding
is reused — only the aligned crop resolution changes.

### The 5 choices in the UI

| Dropdown entry | Aligned crop | Boost factor | Tiles run | Sharpness | Relative cost |
|---|---|---|---|---|---|
| `inswapper_128.onnx` | 128px | x1 (native) | 1 | 1x | 1x |
| `inswapper_128.onnx@256` | 256px | x2 | 4 | ~2x | ~4x |
| `inswapper_128.onnx@512` | 512px | x4 | 16 | ~4x | ~16x |
| `inswapper_128.onnx@1024` | 1024px | x8 | 64 | ~8x | ~64x |
| `inswapper_128.onnx@2048` | 2048px | x16 | 256 | ~16x | ~256x |
| `reswapper_256.onnx` | 256px native | — (no boost) | 1 | — | 1x |

Suffix = **desired aligned resolution**. Internally `parse_swapper_spec()`
converts it to a scale factor relative to the model's native 128px:
`256→x2`, `512→x4`, `1024→x8`, `2048→x16`. Short forms `@2/@4/@8/@16` and
legacy `inswapper_128@256` (auto-gains `.onnx`) resolve identically.

### How it works under the hood (`visenlo/boost.py`)

1. `face_align.norm_crop2(image, kps, 128*factor)` aligns a **larger** crop
   (`big = 128 × factor`).
2. `implode_tiles()` splits it into `factor²` whole-face views, each
   downsampled by `factor` at sub-pixel phase offsets (polyphase
   decomposition, FaceFusion technique). Every tile keeps the model's expected
   128px receptive field, so there are **no seams**.
3. Tiles run **sequentially** through `inswapper_128.onnx` (the graph declares
   fixed batch 1) with the same source identity embedding.
4. `explode_tiles()` interleaves the outputs back to the full `big × big` face.
5. `_paste_back()` warps it to the frame with **Lanczos** (not bilinear) and the
   same erode + feather mask logic as the native swapper.

Input size is detected robustly for both `NCHW` and `NHWC` exports, and mask
kernel sizes are clamped so `@2048` never crashes `cv2` on huge faces.

### Explicit choice vs Best likeness (automatic)

- **Explicit `@256/@512/@1024/@2048` always wins — in both quality modes.**
  If you pick `@512`, Visenlo runs exactly x4, no comparison, no override.
  The report says `requested pixel-boost 512px (x4)`.
- **Plain `inswapper_128.onnx` + Best likeness (default):** Visenlo runs
  **native, 256px, and 512px** candidates (`candidate_boosts_for() → (1, 2, 4)`),
  each in **two finishes** (`default` + `identity-preserving` with color/sharpen
  off) = 6 candidates. It compares fully composited outputs to the reference
  with ArcFace, keeps the **lowest boost within 0.01** of the best score
  (`select_likeness_candidate()`), and reports
  `best-likeness x4 default (compared 128/256/512)`. Deliberately slower than
  Manual — “reference similarity” is a comparison value, not a guarantee the
  image looks convincing.
- **Plain `inswapper_128.onnx` + Manual:** runs **native x1 only**.
- **Pixel Boost is rejected for `reswapper_256.onnx`.** The UI suffixes are only
  valid for `inswapper_128`; the pipeline raises
  `Pixel-boost (@256/@512/…) is not supported for reswapper_256.onnx`.

### When to use what

- **Default (Best likeness, plain 128px):** leave it — best quality/effort
  trade-off for most faces.
- **`@256`:** visibly crisper eyes/teeth on close-ups, still fast. Good first
  manual step up.
- **`@512`:** large prints / 1K+ faces. Noticeably sharper, ~16 tile passes.
- **`@1024` / `@2048`:** forensic crops / huge posters only. 64–256 tile
  passes — use a GPU, expect seconds-to-minutes on CPU. Gains beyond `@512`
  are subtle unless the target face itself is 800px+.

## Gender-based face matching

The **Face matching** control under **Fine-tune** has two modes:

- **Manual (target index)** (default) — swaps the target face at *Target face
  index*, exactly as before.
- **Gender match (auto)** — the pipeline reads the gender of the selected
  reference face (the one at *Reference face index*) and swaps the
  leftmost target face of that gender. The *Target face index* slider is
  hidden in this mode.

Example: a target group photo contains a man and a woman; the reference image
is a woman. With *Gender match (auto)* only the woman's face in the target is
replaced — the man is left untouched. If the target has no face matching the
reference's gender, the swap fails with a clear message listing the detected
target genders.

Gender matching uses a fallible classifier estimate and may select unexpectedly; manual face selection is the default. Gender comes from the `genderage.onnx` attribute model included in the
`buffalo_l` analysis pack (installed under
`models/insightface/models/buffalo_l/`), so no extra download is needed.
Genders are `F`/`M`; when several references are accepted the matched gender is
a majority vote across them. The selected target face's gender and age also
appear in the console log and the pipeline report (`gender-matched (F): target
face 1 of 2`).

## Models

Keep the `buffalo_l` analysis pack in
`Visenlo/models/insightface/models/buffalo_l/`. Existing files are reused. The five files are
`1k3d68.onnx`, `2d106det.onnx`, `det_10g.onnx`, `genderage.onnx`, and
`w600k_r50.onnx`.

The default swap weights belong at `Visenlo/models/inswapper_128.onnx`.
An optional ReSwapper installation belongs at `Visenlo/models/reswapper_256.onnx`. Visenlo uses the standard InsightFace
adapter for the 128px model and a dedicated two-input ONNX adapter for the
256px model, because InsightFace 0.7.3 otherwise misclassifies the latter as
an ArcFace recognition model.
Set `VISENLO_MODELS=/another/path` to use another model directory
(`REACTORX_MODELS` still works as a legacy fallback).

### Getting the models — Model Setup Guide

Model weights are **not included in this repository** (size and license
restrictions) and **are not auto-downloaded** (licensing). The `buffalo_l` analysis pack and swap weights require explicit setup. Run the helper with `--download` after reviewing the upstream licenses; the pipeline never downloads missing analysis models during a swap. The app shows a live checker:

```
[✓/✗] buffalo_l      — Face analysis (5 files, required)
[✓/✗] inswapper_128  — Main swap (required, ~529 MB)
[✓/✗] BiSeNet        — Face parsing (optional)
[✓/✗] XSeg           — Occlusion (~68 MB)
[✓/✗] CodeFormer     — Restoration (~377 MB)
          ↓ required assets ✓ → [Run identity swap]
```

**Install missing models** (from your `Visenlo/` folder):

```bash
BASE=https://huggingface.co/facefusion/models-3.0.0/resolve/main
mkdir -p models
curl -L -o models/bisenet_resnet_34.onnx $BASE/bisenet_resnet_34.onnx   # face parsing, MIT
curl -L -o models/codeformer.onnx     $BASE/codeformer.onnx            # restoration, CC BY-NC 4.0 (alt: models/restoration/codeformer.onnx)
curl -L -o models/inswapper_128.onnx  $BASE/inswapper_128.onnx         # swap model, research-only
# optional occlusion mask (GPL-3.0):
curl -L -o models/xseg_1.onnx https://huggingface.co/facefusion/models-3.1.0/resolve/main/xseg_1.onnx
# buffalo_l manual alt: https://github.com/deepinsight/insightface/releases/download/v0.7/buffalo_l.zip -> models/insightface/models/buffalo_l/
python scripts/download_models.py --check   # verify — should show all ✓
# If you accept licenses and want auto-fetch: python scripts/download_models.py --download
```

`reswapper_256.onnx` is optional and has no canonical public host; without it
the 256px dropdown entry is unavailable. Note that `inswapper_128` and
`reswapper_256` are InsightFace research models — non-commercial use only.
Pixel-boost suffixes (`@256` etc.) are only valid for `inswapper_128`; the UI
rejects them for `reswapper_256` (see Pixel Boost section above).

## CodeFormer restoration

Guarded face-restoration stage (enabled by default). Requires the ONNX conversion of
the full CodeFormer graph at `Visenlo/models/codeformer.onnx` (or
`models/restoration/codeformer.onnx`, ~377 MB, inputs `input [1,3,512,512]`
and `weight` float32 scalar, output the restored 512px face).

- Toggle **Enable guarded CodeFormer restoration** in the UI. It runs only on
  the selected candidate and is discarded when reference similarity decreases.
- **CodeFormer fidelity weight** (`w`, 0..1): lower = stronger restoration,
  higher = keeps the swapped face closer to the swap output. 0.8 is a good
  default; `w` near 1 preserves identity most. The weight is now fed as
  `float32` with correct scalar/`[1]` layout detection to avoid ORT type
  errors on strict builds.
- The pipeline re-aligns the selected candidate to CodeFormer's native 512px
  FFHQ template, restores it, and pastes it through the same face mask. It
  applies the target-preserving corrections afterward.
- An automatic check compares the composited output with the reference identity;
  restoration is rejected when the score falls by more than 0.01.

The model is loaded once and kept in memory. Runtime is hardware-dependent;
Best likeness is substantially slower on CPU because it evaluates three swaps
(see Pixel Boost — explicit `@256/@512` candidates are compared, not just run).

The engine requests InsightFace's 106-point landmark output when available and
falls back conservatively when a runtime only exposes five points. Skin-only
eligibility masks preserve hair, clothing, accessories, body, and background.

This app is intended for images you own or have permission to edit.

## Quality stack

- **Best likeness (default).** Runs unchanged `inswapper_128` at native, 256px,
  and 512px pixel-boost settings (see Pixel Boost above), compares the three
  fully composited outputs to the reference, and keeps the lowest boost within
  0.01 of the best score. It is deliberately slower than Manual mode.
  “Reference similarity” is an ArcFace comparison value, not a guarantee that
  an image looks convincing. Selecting an explicit `@256`, `@512`, `@1024`, or
  `@2048` entry always runs that exact boost in either quality mode.
- **Mouth handling.** The default swaps the reference lips but preserves only
  the target teeth/open-mouth interior. Choose **Keep entire target mouth** for
  expression stability or **Swap entire mouth** when likeness matters more than
  possible teeth artifacts. Teeth protection requires the optional parser.
- **Scene protection.** XSeg occlusion recovery and parsed face-region masks
  keep target hair, body, scene, and other faces out of color correction and
  enhancement while preserving the swapper's own feathered identity blend.
- **GPU acceleration.** The launcher selects a CPU or GPU ONNX Runtime build.
  GPU operation also requires compatible NVIDIA drivers and CUDA/cuDNN libraries. Without a GPU it falls
  back to CPU transparently. If the CUDA provider is advertised but
  `libcublas`/`libcublasLt` is missing (seen as
  `Failed to load ... libonnxruntime_providers_cuda.so`), the pipeline now
  automatically falls back to `CPUExecutionProvider` and retries model load
  instead of failing permanently.
- **Pixel boost.** `inswapper_128@256` / `inswapper_128@512` / `@1024` / `@2048`
  run the 128px model on polyphase tiles of a larger aligned crop (FaceFusion
  technique), yielding 2x/4x/8x/16x sharper swaps with the same identity
  embedding. Input size is detected robustly for both `NCHW` and `NHWC` exports.
  Full details — including tile counts, costs, and Best-likeness comparison
  logic — are in **Pixel Boost — explicit guide** above.
- **Face parsing (BiSeNet).** When `models/bisenet_resnet_34.onnx` is present,
  color matching and sharpening use a skin/feature interior mask derived from
  CelebAMask-HQ parsing instead of a geometric ellipse, so hair and background
  no longer dilute lighting transfer. The parser handles dynamic dims and avoids
  double-linear blurring of binary masks (now `NEAREST` with conditional resize).
- **Occlusion masking (XSeg).** When `models/xseg_1.onnx` is present, objects
  in front of the face (hair strands, glasses, hands) are detected and kept
  from the target scene. Toggle in the UI. The occluder now handles both
  `NCHW` and `NHWC` exports and inverts in crop space before warping.
- **Safer blending.** Landmark-hull face masks follow head roll; masks feather
  with a hard interior (no ghosting); occlusion recovery only touches a thin
  boundary band and blends partially. Kernel sizes are clamped to image size to
  avoid `cv2` errors on huge faces or `2048` boost.
- **Adaptive detection.** Small faces trigger one retry at higher detector
  resolution for more precise landmarks and alignment.
- **Gallery UX.** Fixed 420px crop removed; thumbnails use `contain` on a
  dark letterbox and the preview lightbox is fully zoomable/fullscreenable.

Parsing, occlusion masking, and restoration are optional; the pipeline logs
and falls back when they are unavailable. Analysis and the selected swap model are required.

## Self-check & model helper

```bash
.venv/bin/python scripts/selfcheck.py                # 40+ checks, synthetic data only
.venv/bin/python scripts/download_models.py --check   # checker → guide (no download, default)
.venv/bin/python scripts/download_models.py --download  # actually fetch (only if you accept licenses)
python launcher.py --skip-check                     # skip checks for faster launch
```

Runs unit checks over the engine stages, pixel-boost roundtrips, templates,
and (when present) the BiSeNet/XSeg model adapters using synthetic images.
All 40+ checks should report `ok`; missing optional models are reported as
`[skip]`.

## Docker (optional, still local)

```bash
docker compose up --build
# open http://localhost:7860
# GPU: uncomment deploy.resources in docker-compose.yml + install nvidia-container-toolkit
```

## Alternative swap models

The face-model menu now includes AlphaFace, BlendSwap, GHOST 1/2/3, HifiFace,
HyperSwap 1a/1b/1c, SimSwap 256/512, UniFace, InSwapper FP16, MobileFaceSwap,
and FaceDancer variants alongside the original InSwapper and ReSwapper.
The selected model's weights and optional runtime determine launch readiness.
InSwapper remains the default; masking, mouth controls and restoration remain
Visenlo's existing finishing stages.

```bash
.venv/bin/python scripts/swap_models.py --all                 # check
.venv/bin/python scripts/swap_models.py --download --all      # download verified public assets
.venv/bin/python scripts/setup_mobilefaceswap.py             # optional isolated Paddle runtime + weights
.venv/bin/python scripts/setup_facedancer.py                 # optional isolated TensorFlow runtime
```

FaceDancer's official generator weights require Hugging Face access approval and
are not bundled. Its backend has not been validated with real generator weights.
MobileFaceSwap is native 224px only; unsupported boost sizes are not silently
replaced with resizing. New model `@` suffixes use that model's native resolution.
Image-conditioned models use the highest-quality accepted reference.

See [model inventory and remaining integration work](docs/SWAP_MODELS.md) for
sources, model restrictions and research backends that are not yet implemented.
Run `scripts/compare_swappers.py --all` with the project Python to save actual
local comparisons, then `scripts/report_swappers.py` to build their HTML report.
